from collections import Counter
import re

def openfile(filename):
    strh = ''
    try:
        fh = open(filename, encoding="utf8")
        strh = fh.read()
        return True, strh
    except Exception:
        return False,strh
        
def getwordbins(words):
    return Counter(re.findall('[a-z]+', words.lower()))

def occurance(filename):
    status, file = openfile(filename)
    print(getwordbins(file))

occurance("wiki-en-train.word")