"""
    Author: Devanshi Sukhija
    PRN: 18030142046

    Topic:- Assignment 2: Train and test a Unigram model.

    => Test:
        - Load train_unigram.py
        - Fit the model
            - load trained_model
            - Load test_input
            - unknown_w
            - predict

            -Evaluate the model
            - Entropy
            - Perplexity
            - Coverage
"""
from train_unigram import fit_model, trained_model
import numpy as np
import re
def predict_likelihood(train_file, test_file ,lambd = 0.95):
    # helper inner-function
    def extract_sentences(filepath):
        sentences = list()
        with open(filepath) as file:
            for line in file.readlines():
                sentences.append(" <s> " + re.sub(r'[:.,\'\n]', ' ', line) + " </s> ")
        return sentences

    # fit and load UNIGRAM...
    fit_model(train_file)
    unigram_model = trained_model()

    #constants
    total_unk = 0
    unk_mlprob = 0.0
    H = 0 #entroy
    ppl = 0 #perplexity
    coverage = 0
    N = 28870 #total words in vocab

    # lambda_1 * P(Wi) + (1-lamdba_1)1/N
    # test_data is list of sentences with start tag and end tag
    test_data = extract_sentences('data/wiki-en-test.word.txt')
    # find entropy of all the words
    P = 1-lambd / N
    for sentence in test_data:
        for word in sentence:
            if word in unigram_model:
                P += (lambd) * unigram_model[word]
            else:
                total_unk += 1
            H += np.log2(P)
    print((N- total_unk))
    H= H/N
    coverage = (N - total_unk)/ float(N)
    ppl = 2**H

    return H, coverage, ppl

entropy, coverage , perplexity = predict_likelihood('data/wiki-en-train.word.txt', 'data/wiki-en-test.word.txt' )
print('Entropy : {}\nCoverage: {} \nPerplexity: {}'.format(entropy, coverage, perplexity))
