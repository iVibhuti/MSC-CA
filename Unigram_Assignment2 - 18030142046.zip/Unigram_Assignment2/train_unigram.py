"""
    Author: Devanshi Sukhija
    PRN: 18030142046

    Topic:- Assignment 2: Train and test a Unigram model.

    => Train:
        - Corpus creation
            -striping and insert sentence beginning and ending symbol
            - Learn Probabilities (model_creation)
            - dump the learnt model.
        - Return Model
"""

from collections import defaultdict, Counter
import json
import numpy as np

def fit_model(filepath):
    corpus = Counter()
    learning = {}
    try:
        training_file = open(filepath, 'r').readlines()
        # corpus = defaultdict(int)
        for line in training_file:
            line = ' <s> ' + line + ' </s>'
            # corpus[str(word.strip(':,./;?\!"\'').lower() for word in line.split())] +=1
            corpus.update(word.strip(':,./;?!"\'').lower() for word in line.split())

        n = sum(list(corpus.values()))  # Total sampl
        for of_word, their_frequency in corpus.items():
            learning[of_word] = their_frequency / n
        # save model
        with open('_M_unigram_model', 'w') as file:
            file.write(json.dumps(learning))

    except FileNotFoundError:
        return 'FileNotFound'




def trained_model():
    with open('_M_unigram_model', 'r') as file:
        learning = json.loads(file.read())
    return learning

fit_model("./data/wiki-en-train.word.txt")