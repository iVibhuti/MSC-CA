#!/usr/bin/env python
# coding: utf-8

# In[19]:


import io
import argparse

EOS = '</s>'

def train_unigram(training_file, model_file):
    counts = {}
    total_count = 0
    with open(training_file, 'r') as f:
        for line in f:
            words = line.strip().split(' ')
            words.append(EOS)
            for word in words:
                if word in counts:
                    counts[word] += 1
                else:
                    counts[word] = 1
                total_count += 1

    probabilities = {}
    for word, count in counts.items():
        probabilities[word] = count / total_count

    # Write the info into a buffer.
    out = io.StringIO()
    for word, probability in sorted(probabilities.items(),
                             key=lambda x: x[1], reverse=True):
        out.write('{}\t{}\n'.format(word, probability))

    # Print on the screen or save in the model file.
    if model_file == 'stdout':
        print(out.getvalue().strip())
    else:
        with open(model_file, 'w') as f:
            f.write(out.getvalue().strip())


# In[21]:


train_unigram("../AnoushkaMotwani_20_TA2/wiki-en-test.word","../Untitled Folder/Model.txt")


# In[22]:





# In[23]:


ab = open("../AnoushkaMotwani_20_TA2/test.txt",'r')


# In[15]:





# In[ ]:




