
# coding: utf-8

# In[1]:


from Occurence import open_file, close_file, count_occurence
import unittest
from collections import Counter


# In[2]:


class Tests(unittest.TestCase):
    def test_open_file(self):
        flag, file = open_file("asffgvcg")
        if flag == False:
            self.assertFalse(flag)
        else:
            self.assertTrue(flag)

    def test_close_file(self):
        file = open('./wiki-en-train.word')
        flag = close_file(file)
        if flag == True:
            self.assertTrue(flag)
        else:
            self.assertFalse(flag)
            
    def test_count_occurence(self):
        self.assertEqual(count_occurence('Dude go  Enjoy. Will you \nTake care '),Counter({'care': 1,'dude': 1,'enjoy': 1,'go': 1,'take': 1,'will': 1,'you': 1}))

if __name__ == '__main__':
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

